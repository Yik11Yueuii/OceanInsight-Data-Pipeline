# OceanInsight 学生Starter

本压缩包与 `OceanInsight-project1-source.zip` 配套使用。请在云服务器上完成TODO后，再执行NC、NPZ和年度船舶ZIP处理。

## 学生需要完成的5个TODO

打开 `src/oceaninsight/core.py`，按编号完成：

1. 把经度统一到 `[-180, 180)`。
2. 按2°网格计算左下角坐标和网格编号。
3. 判断坐标是否位于目标海域。
4. 按深度划分 `SURFACE/SHALLOW/MIDDLE/DEEP`。
5. 根据东西、南北流速分量计算流速和流向。

不要改动NC逐文件处理、ZIP逐成员流式处理和临时文件成功后替换的骨架。

## 完成TODO后的检查

```bash
python3 -m unittest discover -s tests -v
python3 -m oceaninsight.cli --help
```

全部测试显示 `OK` 后，才能开始正式转换。具体命令由学生教程逐步给出。

## 数据边界

- NC转换为标准海洋长表CSV。
- 年度ZIP禁止整体解压，必须逐成员、逐行处理。
- NPZ只生成结构、形状、类型和数值范围报告，不转成业务CSV，也不与海洋或船舶数据关联。
- 不得把教师 `expected.zip` 当作学生转换输入。
